library(testthat)
library(jagstargets)

test_check("jagstargets")
