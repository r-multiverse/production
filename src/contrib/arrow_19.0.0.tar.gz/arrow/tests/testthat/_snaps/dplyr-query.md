# Scalars in expressions match the type of the field, if possible

    In int == "5": 
    i Expression not supported in Arrow
    > Pulling data into R

