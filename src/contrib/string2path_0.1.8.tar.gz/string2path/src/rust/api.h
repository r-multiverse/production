SEXP savvy_string2path_family__ffi(SEXP text, SEXP font_family, SEXP font_weight, SEXP font_style, SEXP tolerance);
SEXP savvy_string2path_file__ffi(SEXP text, SEXP font_file, SEXP tolerance);
SEXP savvy_string2stroke_family__ffi(SEXP text, SEXP font_family, SEXP font_weight, SEXP font_style, SEXP tolerance, SEXP line_width);
SEXP savvy_string2stroke_file__ffi(SEXP text, SEXP font_file, SEXP tolerance, SEXP line_width);
SEXP savvy_string2fill_family__ffi(SEXP text, SEXP font_family, SEXP font_weight, SEXP font_style, SEXP tolerance);
SEXP savvy_string2fill_file__ffi(SEXP text, SEXP font_file, SEXP tolerance);
SEXP savvy_dump_fontdb_impl__ffi(void);
