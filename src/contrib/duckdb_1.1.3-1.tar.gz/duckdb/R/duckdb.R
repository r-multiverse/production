## usethis namespace: start
#' @useDynLib duckdb, .registration = TRUE
## usethis namespace: end
#' @name duckdb-package
#' @keywords internal
"_PACKAGE"
NULL
