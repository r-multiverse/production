# Set to TRUE to run tests that have triggered re2 in the past
TEST_RE2 <- FALSE
