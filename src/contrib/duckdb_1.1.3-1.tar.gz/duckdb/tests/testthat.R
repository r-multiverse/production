library("testthat")
library("DBI")

test_check("duckdb")
