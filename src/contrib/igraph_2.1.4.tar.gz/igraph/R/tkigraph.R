#' @name tkigraph
#' @title tkigraph
#' @description Find tkigraph at <https://github.com/igraph/tkigraph>.
#' @keywords internal
NULL
