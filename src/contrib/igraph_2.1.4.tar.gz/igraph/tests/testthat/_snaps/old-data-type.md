# VS/ES require explicit conversion

    Code
      V(karate)
    Condition
      Error in `warn_version()`:
      ! This graph was created by a now unsupported old igraph version.
        Call upgrade_graph() before using igraph functions on that object.

