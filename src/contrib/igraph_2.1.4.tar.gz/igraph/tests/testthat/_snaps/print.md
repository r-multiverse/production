# print.igraph.es() uses vertex names

    Code
      E(g)
    Output
      + 1/1 edge (vertex names):
      [1] A->B

