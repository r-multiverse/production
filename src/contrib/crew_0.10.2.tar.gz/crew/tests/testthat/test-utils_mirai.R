crew_test("daemons_error()", {
  expect_crew_error(daemons_error(5L, "y"))
})
