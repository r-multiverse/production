# serialization works

    Code
      g
    Output
      IGRAPH D--- 3 3 -- Ring graph
      + attr: name (g/c), mutual (g/l), circular (g/l)
      + edges:
      [1] 1->2 2->3 3->1
    Code
      gs
    Output
      IGRAPH D--- 3 3 -- Ring graph
      + attr: name (g/c), mutual (g/l), circular (g/l)
      + edges:
      [1] 1->2 2->3 3->1

