# argument names_prefix works

    Code
      current$collect()
    Condition
      Error in `pivot_longer()`:
      ! `names_prefix` must be of length 1.

