# error messages when error in known function is good

    Code
      current$collect()
    Condition
      Error in `mutate()`:
      ! Error while running function `min_rank()` in Polars.
      x Argument "x" is missing, with no default

---

    Code
      current$collect()
    Condition
      Error in `mutate()`:
      ! Error while running function `dplyr::min_rank()` in Polars.
      x Argument "x" is missing, with no default

