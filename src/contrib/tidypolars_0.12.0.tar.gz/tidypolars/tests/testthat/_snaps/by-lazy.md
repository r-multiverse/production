# .by doesn't work on already grouped data

    Code
      current$collect()
    Condition
      Error in `mutate()`:
      ! Can't supply `.by` when `.data` is a grouped DataFrame or LazyFrame.

