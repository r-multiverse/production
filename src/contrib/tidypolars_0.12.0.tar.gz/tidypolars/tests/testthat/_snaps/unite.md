# name of output column must be provided

    Code
      unite(test)
    Condition
      Error in `unite()`:
      ! `col` is absent but must be supplied.

