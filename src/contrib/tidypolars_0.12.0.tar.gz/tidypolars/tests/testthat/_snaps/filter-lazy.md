# error message when using =

    Code
      current$collect()
    Condition
      Error in `filter()`:
      ! Execution halted with the following contexts
         0: In R: in $filter()
         1: Detected a named input. This usually means that you've used `=` instead of `==`.

