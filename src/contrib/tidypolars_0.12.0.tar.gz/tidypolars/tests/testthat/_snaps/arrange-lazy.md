# errors with unknown vars

    Code
      current$collect()
    Condition
      Error:
      ! object 'foo' not found

---

    Code
      current$collect()
    Condition
      Error:
      ! object 'foo' not found

---

    Code
      current$collect()
    Condition
      Error:
      ! object 'foo' not found

